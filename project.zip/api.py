from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import subprocess
import json
import re

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class AnalyzeRequest(BaseModel):
    country: str
    product_category: str
    sector: Optional[str] = ""
    date_range: Optional[str] = "auto"

@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    # Run your CLI tool and feed it inputs
    proc = subprocess.Popen(
        ["python", "main.py"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    
    # Feed the inputs your CLI expects
    inputs = f"{req.country}\n{req.product_category}\n{req.sector or ''}\n{req.date_range or 'auto'}\n"
    stdout, stderr = proc.communicate(input=inputs, timeout=30)
    
    # Parse the terminal output into JSON
    # (You'll need to adjust this based on what main.py actually prints)
    return {
        "raw_output": stdout,
        "query": {
            "country": req.country,
            "product_category": req.product_category,
            "sector": req.sector,
            "date_range": req.date_range
        }
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)